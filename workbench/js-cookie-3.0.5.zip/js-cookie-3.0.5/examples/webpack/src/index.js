import Cookies from 'js-cookie'

Cookies.set('test', 'example')
